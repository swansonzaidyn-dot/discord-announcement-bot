# Discord Announcement Bot V2

A Discord bot plus a web dashboard for sending and scheduling announcements.

## Features
- Discord OAuth2 dashboard login
- Server list limited to servers where the signed-in user has Manage Server or Administrator
- Channel and role selectors pulled from Discord
- Rich embeds with title, message, color, and footer
- Optional role pings (only the selected role is allowed to mention)
- Send immediately from the dashboard
- Schedule announcements for a future date/time
- Persistent schedules stored in `data/schedules.json`
- Scheduled jobs continue after bot restarts
- `/dashboard` and `/announce` slash commands remain available
- Session storage in SQLite

## Requirements
- Node.js 18.17+
- A Discord application/bot
- OAuth2 client secret for the dashboard

## Discord application setup
1. Create an application in the Discord Developer Portal.
2. Add a bot and copy its bot token.
3. Enable the `bot` and `applications.commands` installation scopes when installing the bot.
4. Give the bot permission to view/send messages in the announcement channels. For role pings, the bot also needs permission to mention the selected role where Discord requires it.
5. In OAuth2 settings, add this redirect URI exactly:
   `http://localhost:3000/auth/callback`
   For production, use your HTTPS dashboard URL instead.
6. Copy the application's Client ID and OAuth2 Client Secret.

## Install
```bash
npm install
cp .env.example .env
```

Edit `.env`:
```env
DISCORD_TOKEN=...
DISCORD_CLIENT_ID=...
DISCORD_CLIENT_SECRET=...
DASHBOARD_URL=http://localhost:3000
SESSION_SECRET=use-a-long-random-secret
PORT=3000
```

Then:
```bash
npm start
```
Open `http://localhost:3000` and click **Sign in with Discord**.

## Production
Use HTTPS for the dashboard and set `DASHBOARD_URL` to the HTTPS URL. Add the same HTTPS callback URL to the Discord application's OAuth2 redirect URIs. Keep `.env` private and never commit it.

## Important security notes
- The Discord bot token never goes to the browser.
- OAuth tokens are stored only in the server-side session store.
- Dashboard API routes verify the user's Discord Manage Server/Administrator permission.
- Role mentions are explicitly limited to the selected role.
- `@everyone` and `@here` are not parsed as mentions by the dashboard.
- For a multi-instance production deployment, replace the local SQLite/JSON stores with shared persistent storage.
