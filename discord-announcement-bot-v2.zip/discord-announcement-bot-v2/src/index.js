require('dotenv').config();

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  PermissionsBitField,
  REST,
  Routes,
  SlashCommandBuilder,
  ChannelType
} = require('discord.js');

const REQUIRED = ['DISCORD_TOKEN', 'DISCORD_CLIENT_ID', 'DISCORD_CLIENT_SECRET', 'DASHBOARD_URL', 'SESSION_SECRET'];
for (const key of REQUIRED) if (!process.env[key]) throw new Error(`Missing ${key} in .env`);

const PORT = Number(process.env.PORT || 3000);
const DASHBOARD_URL = process.env.DASHBOARD_URL.replace(/\/$/, '');
const DATA_DIR = path.join(__dirname, '..', 'data');
const SCHEDULE_FILE = path.join(DATA_DIR, 'schedules.json');
const dbPath = path.join(DATA_DIR, 'sessions.db');
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(SCHEDULE_FILE)) fs.writeFileSync(SCHEDULE_FILE, '[]');

function loadSchedules() {
  try { return JSON.parse(fs.readFileSync(SCHEDULE_FILE, 'utf8')); } catch { return []; }
}
function saveSchedules(items) {
  const tmp = `${SCHEDULE_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(items, null, 2));
  fs.renameSync(tmp, SCHEDULE_FILE);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

function canManageGuild(guild, userId) {
  const member = guild.members.cache.get(userId);
  if (!member) return false;
  return member.permissions.has(PermissionsBitField.Flags.ManageGuild) || member.permissions.has(PermissionsBitField.Flags.Administrator);
}

function safeColor(input) {
  if (!input) return 0x5865F2;
  const value = String(input).trim().replace(/^#/, '');
  return /^[0-9a-fA-F]{6}$/.test(value) ? parseInt(value, 16) : 0x5865F2;
}

function makeEmbed({ title, message, color, footer }) {
  const embed = new EmbedBuilder().setDescription(message).setColor(safeColor(color)).setTimestamp();
  if (title) embed.setTitle(title.slice(0, 256));
  if (footer) embed.setFooter({ text: footer.slice(0, 2048) });
  return embed;
}

function roleMention(roleId) {
  return roleId ? `<@&${roleId}>` : '';
}

async function sendAnnouncement({ guildId, channelId, message, title, color, footer, roleId }) {
  const guild = await client.guilds.fetch(guildId);
  const channel = await guild.channels.fetch(channelId);
  if (!channel || !channel.isTextBased()) throw new Error('Selected channel is not a text channel.');
  const embed = makeEmbed({ title, message, color, footer });
  await channel.send({ content: roleMention(roleId) || undefined, embeds: [embed], allowedMentions: roleId ? { roles: [roleId] } : { parse: [] } });
}

async function processSchedules() {
  let schedules = loadSchedules();
  const now = Date.now();
  let changed = false;
  for (const item of schedules) {
    if (item.status !== 'pending' || new Date(item.sendAt).getTime() > now) continue;
    try {
      await sendAnnouncement(item);
      item.status = 'sent';
      item.sentAt = new Date().toISOString();
    } catch (err) {
      item.status = 'failed';
      item.error = err.message;
    }
    changed = true;
  }
  if (changed) saveSchedules(schedules);
}

function discordAuthUrl(state) {
  const params = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    redirect_uri: `${DASHBOARD_URL}/auth/callback`,
    response_type: 'code',
    scope: 'identify guilds'
  });
  return `https://discord.com/oauth2/authorize?${params}&state=${encodeURIComponent(state)}`;
}

async function exchangeCode(code) {
  const body = new URLSearchParams({
    client_id: process.env.DISCORD_CLIENT_ID,
    client_secret: process.env.DISCORD_CLIENT_SECRET,
    grant_type: 'authorization_code',
    code,
    redirect_uri: `${DASHBOARD_URL}/auth/callback`
  });
  const tokenRes = await fetch('https://discord.com/api/oauth2/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
  if (!tokenRes.ok) throw new Error('Discord OAuth token exchange failed.');
  return tokenRes.json();
}
async function discordApi(endpoint, token) {
  const res = await fetch(`https://discord.com/api/v10${endpoint}`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`Discord API request failed (${res.status}).`);
  return res.json();
}

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: DATA_DIR }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: DASHBOARD_URL.startsWith('https://'), maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
app.use(express.static(path.join(__dirname, 'public')));

function requireAuth(req, res, next) {
  if (!req.session.user || !req.session.oauthToken) return res.status(401).json({ error: 'Not signed in.' });
  next();
}
async function managedGuilds(req) {
  const guilds = await discordApi('/users/@me/guilds', req.session.oauthToken);
  return guilds.filter(g => (Number(g.permissions) & 0x20) !== 0 || (Number(g.permissions) & 0x8) !== 0);
}
async function requireGuildManager(req, res, next) {
  try {
    const guilds = await managedGuilds(req);
    if (!guilds.some(g => g.id === req.params.guildId)) return res.status(403).json({ error: 'You do not have Manage Server permission for this server.' });
    next();
  } catch (e) { res.status(401).json({ error: 'Discord session expired. Please sign in again.' }); }
}

app.get('/auth/login', (req, res) => {
  const state = crypto.randomBytes(24).toString('hex');
  req.session.oauthState = state;
  res.redirect(discordAuthUrl(state));
});
app.get('/auth/callback', async (req, res) => {
  try {
    if (!req.query.code || req.query.state !== req.session.oauthState) return res.status(400).send('Invalid OAuth state.');
    const token = await exchangeCode(req.query.code);
    const user = await discordApi('/users/@me', token.access_token);
    req.session.oauthToken = token.access_token;
    req.session.user = user;
    delete req.session.oauthState;
    res.redirect('/');
  } catch (e) { res.status(500).send('Discord login failed.'); }
});
app.post('/auth/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.get('/api/me', (req, res) => res.json({ user: req.session.user || null }));
app.get('/api/guilds', requireAuth, async (req, res) => {
  try {
    const guilds = await managedGuilds(req);
    res.json(guilds.map(g => ({ id: g.id, name: g.name, icon: g.icon })));
  } catch { res.status(401).json({ error: 'Discord session expired.' }); }
});
app.get('/api/guilds/:guildId/channels', requireAuth, requireGuildManager, async (req, res) => {
  try {
    const guild = await client.guilds.fetch(req.params.guildId);
    const channels = await guild.channels.fetch();
    res.json([...channels.values()].filter(c => c && (c.type === ChannelType.GuildText || c.type === ChannelType.GuildAnnouncement)).map(c => ({ id: c.id, name: c.name, type: c.type })));
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/guilds/:guildId/roles', requireAuth, requireGuildManager, async (req, res) => {
  try {
    const guild = await client.guilds.fetch(req.params.guildId);
    const roles = await guild.roles.fetch();
    res.json([...roles.values()].filter(r => !r.managed && r.id !== guild.id).sort((a,b) => b.position - a.position).map(r => ({ id: r.id, name: r.name })));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

function validateAnnouncement(body) {
  if (!body.guildId || !body.channelId || !body.message) return 'Server, channel, and message are required.';
  if (String(body.message).length > 4000) return 'Message must be 4000 characters or fewer.';
  if (body.title && String(body.title).length > 256) return 'Title must be 256 characters or fewer.';
  if (body.footer && String(body.footer).length > 2048) return 'Footer must be 2048 characters or fewer.';
  return null;
}

app.post('/api/announce', requireAuth, async (req, res) => {
  try {
    const error = validateAnnouncement(req.body); if (error) return res.status(400).json({ error });
    const guilds = await managedGuilds(req); if (!guilds.some(g => g.id === req.body.guildId)) return res.status(403).json({ error: 'No permission for that server.' });
    await sendAnnouncement(req.body);
    res.json({ ok: true });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/api/schedules', requireAuth, async (req, res) => {
  try {
    const error = validateAnnouncement(req.body); if (error) return res.status(400).json({ error });
    if (!req.body.sendAt || Number.isNaN(new Date(req.body.sendAt).getTime()) || new Date(req.body.sendAt).getTime() <= Date.now()) return res.status(400).json({ error: 'Choose a future date and time.' });
    const guilds = await managedGuilds(req); if (!guilds.some(g => g.id === req.body.guildId)) return res.status(403).json({ error: 'No permission for that server.' });
    const item = { id: crypto.randomUUID(), ...req.body, status: 'pending', createdBy: req.session.user.id, createdAt: new Date().toISOString() };
    const schedules = loadSchedules(); schedules.push(item); saveSchedules(schedules);
    res.json({ ok: true, schedule: item });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.get('/api/schedules', requireAuth, async (req, res) => {
  const guilds = await managedGuilds(req); const allowed = new Set(guilds.map(g => g.id));
  res.json(loadSchedules().filter(s => allowed.has(s.guildId)).sort((a,b) => new Date(a.sendAt) - new Date(b.sendAt)));
});
app.delete('/api/schedules/:id', requireAuth, async (req, res) => {
  const guilds = await managedGuilds(req); const allowed = new Set(guilds.map(g => g.id));
  const schedules = loadSchedules(); const item = schedules.find(s => s.id === req.params.id);
  if (!item || !allowed.has(item.guildId)) return res.status(404).json({ error: 'Schedule not found.' });
  saveSchedules(schedules.filter(s => s.id !== req.params.id)); res.json({ ok: true });
});

const commands = [
  new SlashCommandBuilder().setName('announce').setDescription('Send an announcement from Discord.').addStringOption(o => o.setName('message').setDescription('Announcement text').setRequired(true)).setDefaultMemberPermissions(PermissionsBitField.Flags.ManageGuild),
  new SlashCommandBuilder().setName('dashboard').setDescription('Get the announcement dashboard link.').setDefaultMemberPermissions(PermissionsBitField.Flags.ManageGuild)
];

client.once('ready', async () => {
  console.log(`Logged in as ${client.user.tag}`);
  const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands.map(c => c.toJSON()) });
  console.log('Slash commands registered.');
  setInterval(processSchedules, 5000);
  processSchedules();
});
client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;
  if (interaction.commandName === 'dashboard') {
    return interaction.reply({ content: `Announcement dashboard: ${DASHBOARD_URL}`, ephemeral: true });
  }
  if (interaction.commandName === 'announce') {
    if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild)) return interaction.reply({ content: 'You need Manage Server permission.', ephemeral: true });
    const message = interaction.options.getString('message', true);
    const channel = interaction.channel;
    await channel.send({ embeds: [makeEmbed({ title: 'Announcement', message })], allowedMentions: { parse: [] } });
    return interaction.reply({ content: 'Announcement sent.', ephemeral: true });
  }
});

app.listen(PORT, () => console.log(`Dashboard running at ${DASHBOARD_URL}`));
client.login(process.env.DISCORD_TOKEN);
